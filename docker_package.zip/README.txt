# ROS 2 Portable Project

1. Install Docker Desktop.
2. Open terminal in this folder.
3. Build the image:
   docker build -t my_ros2_project .
4. Run the container:
   docker run -it --net=host my_ros2_project
