import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():
    ld = LaunchDescription()

    # === C++ NODES (Compiled) ===
    ld.add_action(Node(
        package='huma',
        executable='Move',
        name='Move',
        output='screen',
        emulate_tty=True
    ))

    ld.add_action(Node(
        package='huma',
        executable='Check_Reachability',
        name='Check_Reachability',
        output='screen',
        emulate_tty=True
    ))

    ld.add_action(Node(
        package='huma',
        executable='Plan_Path',
        name='Plan_Path',
        output='screen',
        emulate_tty=True
    ))

    ld.add_action(Node(
        package='huma',
        executable='Execute',
        name='Execute',
        output='screen',
        emulate_tty=True
    ))

    return ld
