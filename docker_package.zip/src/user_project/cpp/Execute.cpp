#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit_msgs/msg/robot_trajectory.hpp>
#include <std_msgs/msg/bool.hpp>

class ExecuteStandaloneNode : public rclcpp::Node {
public:
    ExecuteStandaloneNode() : Node("execute_path_node", rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true)) {
        // Подключаемся к MoveIt
        move_group_ = std::make_shared<moveit::planning_interface::MoveGroupInterface>(
            std::shared_ptr<rclcpp::Node>(this, [](rclcpp::Node*){}), "left_arm"
        );

        // Входной пин: подписываемся на топик с траекторией от ноды Plan
        sub_traj_ = create_subscription<moveit_msgs::msg::RobotTrajectory>(
            "/blueprint/planned_trajectory", 10,
            std::bind(&ExecuteStandaloneNode::trajectory_callback, this, std::placeholders::_1)
        );

        // Выходной пин: логический статус выполнения
        pub_status_ = create_publisher<std_msgs::msg::Bool>("/blueprint/execute_status", 10);
        
        RCLCPP_INFO(get_logger(), "🚀 Нода Execute готова. Жду траекторию на вход...");
    }

private:
    void trajectory_callback(const moveit_msgs::msg::RobotTrajectory::SharedPtr msg) {
        RCLCPP_INFO(get_logger(), "Получена траектория, отправляю команды на моторы...");
        
        // Восстанавливаем объект Plan из полученного ROS-сообщения
        moveit::planning_interface::MoveGroupInterface::Plan my_plan;
        my_plan.trajectory_ = *msg;

        // Блокирующий вызов исполнения на железе
        auto err_code = move_group_->execute(my_plan);

        // Публикуем результат дальше по графу
        std_msgs::msg::Bool status_msg;
        status_msg.data = (err_code == moveit::core::MoveItErrorCode::SUCCESS);
        
        if (status_msg.data) {
            RCLCPP_INFO(get_logger(), "✅ Движение успешно завершено!");
        } else {
            RCLCPP_ERROR(get_logger(), "❌ Сбой при выполнении на железе.");
        }
        pub_status_->publish(status_msg);
    }

    std::shared_ptr<moveit::planning_interface::MoveGroupInterface> move_group_;
    rclcpp::Subscription<moveit_msgs::msg::RobotTrajectory>::SharedPtr sub_traj_;
    rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr pub_status_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::executors::MultiThreadedExecutor executor;
    auto node = std::make_shared<ExecuteStandaloneNode>();
    executor.add_node(node);
    executor.spin();
    rclcpp::shutdown();
    return 0;
}