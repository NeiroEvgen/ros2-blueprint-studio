#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <memory>

class InitRobotNode 
{
public:
    // Входные пины: указатель на ROS-узел и имя группы (например, "left_arm" или "dual_arm")
    // Выходной пин: std::shared_ptr на интерфейс управления
    static std::shared_ptr<moveit::planning_interface::MoveGroupInterface> execute(
        std::shared_ptr<rclcpp::Node> builtin_node, 
        const std::string& planning_group = "left_arm")
    {
        RCLCPP_INFO(builtin_node->get_logger(), "[Init Robot] Подключение к группе: %s...", planning_group.c_str());

        // Создаем интерфейс. Под капотом он стучится в топики ROS 2,
        // забирает URDF/SRDF с сервера параметров и подключается к action-серверу MoveIt.
        auto move_group = std::make_shared<moveit::planning_interface::MoveGroupInterface>(
            builtin_node, 
            planning_group
        );

        // --- БАЗОВЫЕ НАСТРОЙКИ БЕЗОПАСНОСТИ ---
        // Жестко режем скорость и ускорение при инициализации (Sim2Real gap)
        // Потом их можно будет вынести в отдельную ноду "Set Speed"
        move_group->setMaxVelocityScalingFactor(0.1);      // 10% от максимальной скорости
        move_group->setMaxAccelerationScalingFactor(0.1);  // 10% от максимального ускорения
        
        // Настройки планировщика (наш аналог микро-степпинга и shotgun-поиска)
        move_group->setPlanningTime(5.0);                  // Даем 5 секунд на раздумья
        move_group->setNumPlanningAttempts(10);            // Количество попыток обойти коллизии

        RCLCPP_INFO(builtin_node->get_logger(), "[Init Robot] Группа %s успешно инициализирована и готова к работе.", planning_group.c_str());
        
        return move_group; 
    }
};