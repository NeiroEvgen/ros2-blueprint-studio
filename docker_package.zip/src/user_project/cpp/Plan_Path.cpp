#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <geometry_msgs/msg/pose.hpp>
#include <std_msgs/msg/bool.hpp>

class PlanPathStandaloneNode : public rclcpp::Node {
public:
    PlanPathStandaloneNode() : Node("plan_path_node", rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true)) {
        // Инициализируем интерфейс MoveIt
        move_group_ = std::make_shared<moveit::planning_interface::MoveGroupInterface>(
            std::shared_ptr<rclcpp::Node>(this, [](rclcpp::Node*){}), "left_arm"
        );

        // Подписываемся на топик с целевой позой (входной пин в Blueprint)
        sub_pose_ = create_subscription<geometry_msgs::msg::Pose>(
            "/blueprint/target_pose", 10,
            std::bind(&PlanPathStandaloneNode::pose_callback, this, std::placeholders::_1)
        );

        // Паблишер для результата (выходной пин в Blueprint)
        pub_status_ = create_publisher<std_msgs::msg::Bool>("/blueprint/plan_status", 10);

        RCLCPP_INFO(get_logger(), "🟢 Plan Path Node готова. Жду цель...");
    }

private:
    void pose_callback(const geometry_msgs::msg::Pose::SharedPtr msg) {
        RCLCPP_INFO(get_logger(), "Получена новая цель, запускаю планировщик...");
        
        move_group_->setPoseTarget(*msg);
        
        moveit::planning_interface::MoveGroupInterface::Plan my_plan;
        auto err_code = move_group_->plan(my_plan);

        std_msgs::msg::Bool status_msg;
        if (err_code == moveit::core::MoveItErrorCode::SUCCESS) {
            RCLCPP_INFO(get_logger(), "✅ План успешно построен!");
            status_msg.data = true;
            // Здесь можно было бы опубликовать сам план в другой топик
        } else {
            RCLCPP_WARN(get_logger(), "❌ Ошибка планирования.");
            status_msg.data = false;
        }
        pub_status_->publish(status_msg);
    }

    std::shared_ptr<moveit::planning_interface::MoveGroupInterface> move_group_;
    rclcpp::Subscription<geometry_msgs::msg::Pose>::SharedPtr sub_pose_;
    rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr pub_status_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    // Для MoveIt обязательно нужен MultiThreadedExecutor!
    rclcpp::executors::MultiThreadedExecutor executor;
    auto node = std::make_shared<PlanPathStandaloneNode>();
    executor.add_node(node);
    executor.spin();
    rclcpp::shutdown();
    return 0;
}