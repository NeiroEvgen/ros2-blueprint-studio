#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/robot_state/robot_state.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <memory>

class CheckReachabilityNode 
{
public:
    // Входные пины: 
    // 1. Указатель на move_group (синяя линия от ноды Init Robot)
    // 2. Координаты x, y, z
    // 3. Углы roll, pitch, yaw (в градусах для удобного ввода в UI)
    // Выходной пин: bool (достижима ли точка)
    static bool execute(
        std::shared_ptr<moveit::planning_interface::MoveGroupInterface> move_group,
        double x, double y, double z,
        double roll_deg, double pitch_deg, double yaw_deg)
    {
        // Базовая защита: если не подключили ноду Init Robot
        if (!move_group) {
            RCLCPP_ERROR(rclcpp::get_logger("CheckReachability"), "[-] MoveGroupPtr пустой! Сначала инициализируй робота.");
            return false;
        }

        // 1. Формируем целевую позу (Pose)
        geometry_msgs::msg::Pose target_pose;
        target_pose.position.x = x;
        target_pose.position.y = y;
        target_pose.position.z = z;

        // Конвертация Эйлеровых углов (градусы) в Кватернион (формат ROS)
        tf2::Quaternion q;
        q.setRPY(roll_deg * M_PI / 180.0, pitch_deg * M_PI / 180.0, yaw_deg * M_PI / 180.0);
        target_pose.orientation = tf2::toMsg(q);

        // 2. Получаем слепок текущего состояния робота
        // Таймаут 1.0 сек на случай, если robot_state_publisher задерживает данные
        moveit::core::RobotStatePtr current_state = move_group->getCurrentState(1.0); 
        if (!current_state) {
            RCLCPP_ERROR(rclcpp::get_logger("CheckReachability"), "[-] Не удалось получить текущее состояние суставов.");
            return false;
        }

        const moveit::core::JointModelGroup* joint_model_group = 
            current_state->getJointModelGroup(move_group->getName());

        // 3. --- БЫСТРЫЙ ТЕСТ КИНЕМАТИКИ (IK) ---
        // Пытаемся найти решение обратной кинематики для целевой точки
        // timeout = 0.1 сек (этого с головой хватит для KDL/BioIK, чтобы ответить Да/Нет)
        double ik_timeout = 0.1;
        bool found_ik = current_state->setFromIK(joint_model_group, target_pose, ik_timeout);

        if (found_ik) {
            RCLCPP_INFO(rclcpp::get_logger("CheckReachability"), 
                "[+] ЦЕЛЬ ДОСТИЖИМА: [%.2f, %.2f, %.2f]. Суставы в пределах лимитов.", x, y, z);
            return true;
        } else {
            RCLCPP_WARN(rclcpp::get_logger("CheckReachability"), 
                "[X] ОШИБКА ДОСЯГАЕМОСТИ: Точка [%.2f, %.2f, %.2f] слишком далеко или нарушает анатомию.", x, y, z);
            return false;
        }
    }
};