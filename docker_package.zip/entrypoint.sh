#!/bin/bash
set -e

# Подключаем глобальное окружение
source /opt/ros/humble/setup.bash

# Подключаем локальное окружение, если проект был скомпилирован
if [ -f /app/ros2_ws/install/setup.bash ]; then 
    source /app/ros2_ws/install/setup.bash
fi

# Запуск проекта
echo " Starting ROS 2 Blueprint Node..."
exec ros2 launch /app/ros2_ws/src/user_project/launch/project_launch.py
